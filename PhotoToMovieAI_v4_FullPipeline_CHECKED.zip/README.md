# PhotoToMovie AI v4 — Full Offline Pipeline

Pipeline:
1. Photo input
2. Optional microphone recording / audio import
3. Script analysis -> emotion + motion + camera plan
4. Face landmarks / expression stage
5. Pose stage
6. Segmentation / foreground isolation
7. 2.5D camera/parallax stage
8. OpenGL ES frame-by-frame rendering
9. MediaCodec H.264 MP4

The project is designed to keep RAM usage bounded by processing frames rather
than loading a complete 10-minute movie into memory.

## Important technical limitation

This version can record/import audio and carries an emotion/motion plan into the
render pipeline. It does NOT claim neural phoneme-level lip-sync. Exact
mouth-to-speech timing requires an ASR/phoneme or audio-to-viseme model and a
licensed face-warping/generative model.

Likewise, pose/segmentation data is used for planning/focus/parallax; full
neural body re-animation is a separate model and is not fabricated here.

Real TFLite binaries are intentionally not faked. Put licensed model binaries
in `assets/models/` or implement a first-run downloader with verified licenses.

## Android build

Use JDK 17 and an Android Gradle Plugin version compatible with the included
Gradle setup. The GitHub Actions workflow builds a debug APK and uploads it as
an artifact.


## Build verification fixes
- One shared `Emotion` enum is used; duplicate declaration removed.
- `RepositoriesMode` import added to `settings.gradle.kts`.
- GitHub Actions now expects `PhotoToMovieAI_v4_FullPipeline.zip` and extracts that exact archive.
- Java/Kotlin targets remain aligned at JVM 17.
