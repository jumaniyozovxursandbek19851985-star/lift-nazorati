
package com.photomovie.ai

data class MouthKeyframe(val timeMs: Long, val openness: Float, val emotion: Emotion)

object EmotionLipSyncPlanner {
    private val happy = listOf("кулади", "кулди", "хурсанд", "табассум", "laugh", "smile")
    private val sad = listOf("хафа", "йиғлай", "йиглай", "sad", "cry")
    private val surprised = listOf("ҳайрон", "хайрон", "ажаблан", "surprise", "wow")
    private val angry = listOf("жаҳл", "жахл", "аччиқ", "angry")
    private val scared = listOf("қўрқ", "қурқ", "scared", "afraid")

    fun emotionFor(script: String): Emotion {
        val s = script.lowercase()
        return when {
            happy.any(s::contains) -> Emotion.HAPPY
            sad.any(s::contains) -> Emotion.SAD
            surprised.any(s::contains) -> Emotion.SURPRISED
            angry.any(s::contains) -> Emotion.ANGRY
            scared.any(s::contains) -> Emotion.SCARED
            else -> Emotion.NEUTRAL
        }
    }

    /**
     * Offline phoneme-free lip-sync approximation.
     * Real phoneme alignment requires audio/ASR phoneme timing.
     */
    fun makeKeyframes(text: String, durationMs: Long): List<MouthKeyframe> {
        val chars = text.filter { !it.isWhitespace() }
        if (chars.isEmpty()) return listOf(MouthKeyframe(0, 0f, emotionFor(text)))
        val step = (durationMs / chars.length.coerceAtLeast(1)).coerceAtLeast(70L)
        val emotion = emotionFor(text)
        return chars.mapIndexed { i, ch ->
            val openness = when (ch.lowercaseChar()) {
                'а','о','э','е','и','у','ў','о','a','e','i','o','u' -> 0.65f
                else -> 0.28f
            }
            MouthKeyframe((i * step).coerceAtMost(durationMs), openness, emotion)
        }
    }
}
