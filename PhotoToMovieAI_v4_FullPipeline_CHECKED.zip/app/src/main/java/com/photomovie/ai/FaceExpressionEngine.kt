
package com.photomovie.ai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

enum class Emotion { NEUTRAL, HAPPY, SAD, SURPRISED, ANGRY, SCARED }

data class FaceExpression(
    val boundsLeft: Float,
    val boundsTop: Float,
    val boundsRight: Float,
    val boundsBottom: Float,
    val smile: Float,
    val eyeOpen: Float,
    val mouthOpen: Float,
    val emotion: Emotion
)

class FaceExpressionEngine {
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .build()
    )

    suspend fun detect(bitmap: Bitmap): FaceExpression? {
        val image = InputImage.fromBitmap(bitmap, 0)
        val faces = suspendCancellableCoroutine<List<Face>> { cont ->
            detector.process(image)
                .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }
        val f = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return null
        val smile = (f.smilingProbability ?: 0f).coerceIn(0f, 1f)
        val left = (f.leftEyeOpenProbability ?: 0.5f).coerceIn(0f, 1f)
        val right = (f.rightEyeOpenProbability ?: 0.5f).coerceIn(0f, 1f)
        val eyeOpen = (left + right) / 2f

        val mouth = f.getContour(FaceContour.MOUTH_BOTTOM)?.points
        val mouthOpen = if (!mouth.isNullOrEmpty()) {
            val ys = mouth.map { it.y }
            ((ys.maxOrNull()!! - ys.minOrNull()!!) / f.boundingBox.height().toFloat())
                .coerceIn(0f, 1f)
        } else 0f

        val emotion = when {
            smile > 0.62f -> Emotion.HAPPY
            eyeOpen < 0.22f -> Emotion.SAD
            eyeOpen > 0.92f && mouthOpen > 0.18f -> Emotion.SURPRISED
            else -> Emotion.NEUTRAL
        }

        return FaceExpression(
            f.boundingBox.left.toFloat() / bitmap.width,
            f.boundingBox.top.toFloat() / bitmap.height,
            f.boundingBox.right.toFloat() / bitmap.width,
            f.boundingBox.bottom.toFloat() / bitmap.height,
            smile, eyeOpen, mouthOpen, emotion
        )
    }

    fun close() { detector.close() }
}
