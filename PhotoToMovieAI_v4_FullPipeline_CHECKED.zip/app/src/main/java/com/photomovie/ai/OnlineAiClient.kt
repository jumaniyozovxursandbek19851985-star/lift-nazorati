package com.photomovie.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object AiConfig {
    // Replace with your own server only if you have one.
    const val BASE_URL = ""
}

data class OnlineAiResult(val videoUrl: String? = null, val error: String? = null)

class OnlineAiClient(private val context: Context) {
    suspend fun animate(image: Uri, script: String, motion: CharacterMotion): OnlineAiResult =
        withContext(Dispatchers.IO) {
            if (AiConfig.BASE_URL.isBlank())
                return@withContext OnlineAiResult(error = "Online AI сервери уланмаган.")
            try {
                val c = URL(AiConfig.BASE_URL).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15_000
                c.readTimeout = 120_000
                c.setRequestProperty("Content-Type", "application/json")
                val body = """{"script":${json(script)},"motion":"$motion"}"""
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode !in 200..299)
                    return@withContext OnlineAiResult(error = "HTTP ${c.responseCode}")
                OnlineAiResult(error = "Сервер жавоб формати ҳали уланмаган.")
            } catch (e: Exception) {
                OnlineAiResult(error = e.message ?: "Network error")
            }
        }

    private fun json(s: String) =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""
}
