package com.photomovie.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Models are downloaded once, then kept locally. After the first successful
 * download the app can run without internet.
 *
 * IMPORTANT: before redistributing the APK with these binaries bundled,
 * verify the current model licenses and attribution requirements.
 */
object ModelManager {
    private const val POSE_URL =
        "https://tfhub.dev/google/lite-model/movenet/singlepose/lightning/4?lite-format=tflite"

    private const val SEG_URL =
        "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite"

    private fun dir(context: Context) =
        File(context.filesDir, "models").apply { mkdirs() }

    fun poseFile(context: Context) = File(dir(context), "pose_landmark.tflite")
    fun segmentationFile(context: Context) = File(dir(context), "segmentation.tflite")

    suspend fun ensureModels(context: Context): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            downloadIfMissing(POSE_URL, poseFile(context))
            downloadIfMissing(SEG_URL, segmentationFile(context))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun downloadIfMissing(url: String, target: File) {
        if (target.exists() && target.length() > 1024L) return
        val tmp = File(target.parentFile, target.name + ".part")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 120_000
            instanceFollowRedirects = true
        }
        c.connect()
        if (c.responseCode !in 200..299) {
            c.disconnect()
            throw IllegalStateException("Model download failed: HTTP ${c.responseCode}")
        }
        c.inputStream.use { input ->
            tmp.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
        }
        c.disconnect()
        if (tmp.length() <= 1024L) {
            tmp.delete()
            throw IllegalStateException("Downloaded model is empty")
        }
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
    }
}
