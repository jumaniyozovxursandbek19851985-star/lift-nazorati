
package com.photomovie.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.sin

/**
 * Lightweight offline face animation layer.
 *
 * It does not invent pixels like a generative image-to-video model.
 * It applies deterministic mesh-like transforms to the detected face crop:
 * smile = subtle horizontal/vertical deformation, surprise = scale, sad = tilt.
 */
object FaceAnimationEngine {
    fun apply(
        source: Bitmap,
        face: FaceExpression?,
        emotion: Emotion,
        mouthOpen: Float,
        t: Float
    ): Bitmap {
        if (face == null) return source

        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val l = (face.boundsLeft * source.width).toInt().coerceIn(0, source.width - 1)
        val top = (face.boundsTop * source.height).toInt().coerceIn(0, source.height - 1)
        val r = (face.boundsRight * source.width).toInt().coerceIn(l + 1, source.width)
        val b = (face.boundsBottom * source.height).toInt().coerceIn(top + 1, source.height)
        val crop = Bitmap.createBitmap(source, l, top, r - l, b - top)

        val cx = (l + r) / 2f
        val cy = (top + b) / 2f
        val pulse = sin(t * Math.PI * 2.0).toFloat()

        val sx = when (emotion) {
            Emotion.HAPPY -> 1.0f + 0.025f * pulse
            Emotion.SURPRISED -> 1.0f + 0.045f * pulse
            Emotion.SAD -> 1.0f - 0.015f * pulse
            else -> 1.0f
        }
        val sy = when (emotion) {
            Emotion.HAPPY -> 1.0f - 0.015f * pulse
            Emotion.SURPRISED -> 1.0f + 0.055f * pulse + mouthOpen * 0.02f
            Emotion.SAD -> 1.0f + 0.015f * pulse
            else -> 1.0f
        }

        val m = Matrix().apply {
            setScale(sx, sy, crop.width / 2f, crop.height / 2f)
            if (emotion == Emotion.SAD) postRotate(-1.2f * pulse, crop.width / 2f, crop.height / 2f)
        }
        canvas.save()
        canvas.clipRect(l, top, r, b)
        canvas.drawBitmap(crop, m, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            // draw crop centered back into face rectangle
        })
        canvas.restore()
        crop.recycle()
        return out
    }
}
