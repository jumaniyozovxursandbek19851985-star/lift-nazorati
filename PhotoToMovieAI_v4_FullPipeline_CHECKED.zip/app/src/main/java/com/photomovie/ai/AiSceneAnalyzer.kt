package com.photomovie.ai

import android.content.Context
import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight on-device scene analysis. It does not generate a new image;
 * it finds a useful subject focus point from the local TFLite models so the
 * renderer can create a more natural photo-to-video camera move.
 */
object AiSceneAnalyzer {
    data class Result(val x: Float, val y: Float, val scale: Float, val usedPose: Boolean, val usedMask: Boolean)

    fun analyze(context: Context, bitmap: Bitmap): Result {
        var focusX = 0.5f
        var focusY = 0.5f
        var scale = 1f
        var usedPose = false
        var usedMask = false

        // MoveNet gives a stable subject center and is useful even when the
        // segmentation model is unavailable.
        if (ModelManager.poseFile(context).exists()) {
            runCatching {
                PoseEngine(context).use { engine ->
                    val points = engine.detect(bitmap).filter { it.score >= 0.35f }
                    if (points.isNotEmpty()) {
                        focusX = points.map { it.x }.average().toFloat().coerceIn(0f, 1f)
                        focusY = points.map { it.y }.average().toFloat().coerceIn(0f, 1f)
                        usedPose = true
                    }
                }
            }
        }

        // If available, use the foreground mask to estimate how much of the
        // frame the subject occupies. Fail softly because model tensor layouts
        // differ between segmentation model releases.
        if (ModelManager.segmentationFile(context).exists()) {
            runCatching {
                SegmentationEngine(context).use { engine ->
                    val mask = engine.mask(bitmap)
                    val w = mask.width
                    val h = mask.height
                    val pixels = ByteArray(w * h)
                    mask.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(pixels))
                    var minX = w
                    var minY = h
                    var maxX = -1
                    var maxY = -1
                    var count = 0
                    for (y in 0 until h) for (x in 0 until w) {
                        val a = pixels[y * w + x].toInt() and 0xff
                        if (a >= 100) {
                            minX = min(minX, x); minY = min(minY, y)
                            maxX = max(maxX, x); maxY = max(maxY, y)
                            count++
                        }
                    }
                    if (count > 50 && maxX >= minX && maxY >= minY) {
                        focusX = ((minX + maxX) * 0.5f / w).coerceIn(0f, 1f)
                        focusY = ((minY + maxY) * 0.5f / h).coerceIn(0f, 1f)
                        val bw = (maxX - minX + 1).toFloat() / w
                        val bh = (maxY - minY + 1).toFloat() / h
                        val coverage = max(bw, bh).coerceIn(0.2f, 1f)
                        scale = (0.72f / coverage).coerceIn(0.95f, 1.35f)
                        usedMask = true
                    }
                    mask.recycle()
                }
            }
        }
        return Result(focusX, focusY, scale, usedPose, usedMask)
    }
}
