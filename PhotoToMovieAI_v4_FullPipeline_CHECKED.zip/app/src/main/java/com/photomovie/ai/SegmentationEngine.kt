package com.photomovie.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * Generic TFLite foreground-mask runner for the downloaded selfie segmenter.
 * The exact tensor contract is checked at runtime; no fake model is embedded.
 */
class SegmentationEngine(context: Context) : AutoCloseable {
    private val interpreter: Interpreter

    init {
        val file = ModelManager.segmentationFile(context)
        require(file.exists()) { "segmentation.tflite топилмади. Аввал моделни юкланг." }
        val buffer = FileInputStream(file).channel.use {
            it.map(FileChannel.MapMode.READ_ONLY, 0, it.size())
        }
        interpreter = Interpreter(buffer)
    }

    fun mask(bitmap: Bitmap): Bitmap {
        val inShape = interpreter.getInputTensor(0).shape()
        require(inShape.size == 4) { "Segmentation input tensor қўллаб-қувватланмади" }
        val h = inShape[1]
        val w = inShape[2]
        val input = ByteBuffer.allocateDirect(w * h * 3 * 4).order(ByteOrder.nativeOrder())
        val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val pixels = IntArray(w * h)
        scaled.getPixels(pixels, 0, w, 0, 0, w, h)
        for (p in pixels) {
            input.putFloat(Color.red(p) / 255f)
            input.putFloat(Color.green(p) / 255f)
            input.putFloat(Color.blue(p) / 255f)
        }
        input.rewind()

        val out = interpreter.getOutputTensor(0).shape()
        require(out.size == 4) { "Segmentation output tensor қўллаб-қувватланмади" }
        val oh = out[1]
        val ow = out[2]
        val oc = out[3]
        val data = Array(1) { Array(oh) { Array(ow) { FloatArray(oc) } } }
        interpreter.run(input, data)

        val result = Bitmap.createBitmap(ow, oh, Bitmap.Config.ALPHA_8)
        val alpha = ByteArray(ow * oh)
        for (y in 0 until oh) for (x in 0 until ow) {
            val v = data[0][y][x][0].coerceIn(0f, 1f)
            alpha[y * ow + x] = (v * 255f).toInt().toByte()
        }
        result.copyPixelsFromBuffer(ByteBuffer.wrap(alpha))
        return result
    }

    override fun close() = interpreter.close()
}
