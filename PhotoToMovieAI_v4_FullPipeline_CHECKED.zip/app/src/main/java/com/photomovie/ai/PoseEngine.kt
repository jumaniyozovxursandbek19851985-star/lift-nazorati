package com.photomovie.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

data class PosePoint(val x: Float, val y: Float, val score: Float)

class PoseEngine(context: Context) : AutoCloseable {
    private val interpreter: Interpreter

    init {
        val file = ModelManager.poseFile(context)
        require(file.exists()) { "pose_landmark.tflite топилмади. Аввал моделни юкланг." }
        val buffer = FileInputStream(file).channel.use {
            it.map(FileChannel.MapMode.READ_ONLY, 0, it.size())
        }
        interpreter = Interpreter(buffer)
    }

    fun detect(bitmap: Bitmap): List<PosePoint> {
        val size = 192
        val scaled = Bitmap.createScaledBitmap(bitmap, size, size, true)
        val input = ByteBuffer.allocateDirect(1 * size * size * 3 * 4).order(ByteOrder.nativeOrder())
        val pixels = IntArray(size * size)
        scaled.getPixels(pixels, 0, size, 0, 0, size, size)
        for (p in pixels) {
            input.putFloat(Color.red(p) / 255f)
            input.putFloat(Color.green(p) / 255f)
            input.putFloat(Color.blue(p) / 255f)
        }
        input.rewind()

        val output = Array(1) { Array(1) { Array(17) { FloatArray(3) } } }
        interpreter.run(input, output)

        return output[0][0].map {
            PosePoint(it[1], it[0], it[2])
        }
    }

    override fun close() = interpreter.close()
}
