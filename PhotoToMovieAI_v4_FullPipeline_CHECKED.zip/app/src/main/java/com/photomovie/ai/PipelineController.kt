package com.photomovie.ai

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Single orchestration point:
 * audio -> cue/emotion plan -> face/pose/parallax render stages -> H.264.
 *
 * The current offline implementation uses text/emotion cues and audio as the
 * soundtrack source. True phoneme-level lip-sync requires an ASR/phoneme model.
 */
class PipelineController(private val context: Context) {
    fun makePlan(script: String, durationMs: Long): PipelinePlan =
        FullPipeline.plan(script, durationMs)

    fun recordingFile(): File =
        File(context.getExternalFilesDir("Movies"), "recorded_audio.m4a")

    suspend fun inspectAudio(uri: Uri): Result<Long> =
        FullPipeline.prepareAudio(context, uri)
}
