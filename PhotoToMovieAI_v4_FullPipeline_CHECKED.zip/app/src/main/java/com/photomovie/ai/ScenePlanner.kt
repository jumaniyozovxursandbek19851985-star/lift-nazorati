package com.photomovie.ai

object ScenePlanner {
    fun create(script: String): List<Pair<CharacterMotion, CameraMotion>> {
        val s = script.lowercase()
        val result = mutableListOf<Pair<CharacterMotion, CameraMotion>>()

        if (listOf("футбол", "тўп", "futbol", "football").any(s::contains))
            result += CharacterMotion.RUN to CameraMotion.FOLLOW
        if (listOf("югур", "югуриш", "боради", "юради").any(s::contains))
            result += CharacterMotion.RUN to CameraMotion.FOLLOW
        if (listOf("қўл", "силк", "салом").any(s::contains))
            result += CharacterMotion.WAVE to CameraMotion.ZOOM_IN
        if (listOf("теп", "зарба", "kick").any(s::contains))
            result += CharacterMotion.RUN to CameraMotion.PAN_RIGHT
        if (listOf("қара", "кўр", "look").any(s::contains))
            result += CharacterMotion.LOOK to CameraMotion.PAN_LEFT

        if (result.isEmpty())
            result += CharacterMotion.NONE to CameraMotion.ZOOM_IN

        return result
    }
}
