package com.photomovie.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AudioCue(
    val startMs: Long,
    val endMs: Long,
    val text: String = "",
    val emotion: Emotion = Emotion.NEUTRAL
)

data class PipelinePlan(
    val cues: List<AudioCue>,
    val motion: CharacterMotion,
    val camera: CameraMotion,
    val useFace: Boolean = true,
    val usePose: Boolean = true,
    val useParallax: Boolean = true
)

object FullPipeline {
    fun plan(script: String, durationMs: Long): PipelinePlan {
        val lower = script.lowercase()
        val emotion = when {
            listOf("кулади", "кулди", "хурсанд", "қувон", "laugh", "happy").any(lower::contains) -> Emotion.HAPPY
            listOf("хафа", "йиғ", "йиг", "sad", "cry").any(lower::contains) -> Emotion.SAD
            listOf("ҳайрон", "ажаб", "surprise").any(lower::contains) -> Emotion.SURPRISED
            listOf("жаҳл", "аччиқ", "angry").any(lower::contains) -> Emotion.ANGRY
            listOf("қўрқ", "қўрқув", "scared").any(lower::contains) -> Emotion.SCARED
            else -> Emotion.NEUTRAL
        }

        val motion = when {
            listOf("югур", "футбол", "юради", "run", "football").any(lower::contains) -> CharacterMotion.RUN
            listOf("қўл сил", "салом", "wave").any(lower::contains) -> CharacterMotion.WAVE
            else -> CharacterMotion.NONE
        }

        val camera = if (motion == CharacterMotion.RUN)
            CameraMotion.FOLLOW else CameraMotion.ZOOM_IN

        val safeDuration = durationMs.coerceAtLeast(1000)
        val cue = AudioCue(0, safeDuration, script, emotion)

        return PipelinePlan(listOf(cue), motion, camera)
    }

    suspend fun prepareAudio(context: Context, audio: Uri): Result<Long> =
        withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openAssetFileDescriptor(audio, "r")?.use {
                    Result.success(it.length.coerceAtLeast(0L))
                } ?: Result.failure(IllegalStateException("Аудио очилмади"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
