package com.photomovie.ai

import android.media.MediaRecorder
import android.os.Build
import java.io.File

class AudioRecorder(private val output: File) {
    private var recorder: MediaRecorder? = null

    fun start() {
        output.parentFile?.mkdirs()
        recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder() else MediaRecorder()
        recorder!!.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128_000)
            setAudioSamplingRate(44_100)
            setOutputFile(output.absolutePath)
            prepare()
            start()
        }
    }

    fun stop(): File {
        val r = recorder ?: error("Recorder ишга тушмаган")
        try { r.stop() } finally {
            r.reset()
            r.release()
            recorder = null
        }
        return output
    }
}
