package com.photomovie.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.*
import android.net.Uri
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sin

object OfflineRenderer {
    private const val W = 1280
    private const val H = 720
    private const val FPS = 30

    suspend fun render(context: Context, project: MovieProject): Result<File> =
        withContext(Dispatchers.Default) {
            try {
                require(project.scenes.isNotEmpty()) { "Сурат танланмаган." }
                require(project.totalDurationMs in 1..600_000) { "Давомийлик 10 дақиқадан ошмасин." }

                val dir = File(context.getExternalFilesDir("Movies"), "PhotoToMovie").apply { mkdirs() }
                val out = File(dir, "movie_${System.currentTimeMillis()}.mp4")
                val format = MediaFormat.createVideoFormat("video/avc", W, H).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
                    setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                }

                val codec = MediaCodec.createEncoderByType("video/avc")
                codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val inputSurface = codec.createInputSurface()
                val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                val renderer = GlesVideoRenderer(inputSurface, W, H)
                var track = -1
                var muxerStarted = false

                fun drain(end: Boolean) {
                    val info = MediaCodec.BufferInfo()
                    while (true) {
                        val index = codec.dequeueOutputBuffer(info, 10_000)
                        when {
                            index == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!end) return
                            index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                if (muxerStarted) error("Encoder format changed twice")
                                track = muxer.addTrack(codec.outputFormat)
                                muxer.start()
                                muxerStarted = true
                            }
                            index >= 0 -> {
                                val data = codec.getOutputBuffer(index) ?: error("No encoder buffer")
                                if (info.size > 0 && muxerStarted) {
                                    data.position(info.offset)
                                    data.limit(info.offset + info.size)
                                    muxer.writeSampleData(track, data, info)
                                }
                                codec.releaseOutputBuffer(index, false)
                                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                            }
                        }
                    }
                }

                codec.start()

                var sceneIndex = 0
                var sceneStart = 0L
                var bitmap: Bitmap? = null
                var aiFocusX = 0.5f
                var aiFocusY = 0.5f
                var aiScale = 1f

                fun loadScene(uri: Uri): Bitmap {
                    return context.contentResolver.openInputStream(uri).use {
                        BitmapFactory.decodeStream(it) ?: error("Расмни очиб бўлмади: $uri")
                    }
                }

                val totalFrames = (project.totalDurationMs * FPS / 1000L).toInt().coerceAtLeast(1)

                for (frame in 0 until totalFrames) {
                    val tMs = frame * 1000L / FPS
                    while (sceneIndex < project.scenes.lastIndex &&
                        tMs >= sceneStart + project.scenes[sceneIndex].durationMs) {
                        sceneStart += project.scenes[sceneIndex].durationMs
                        bitmap?.recycle()
                        bitmap = null
                        sceneIndex++
                    }

                    if (bitmap == null) {
                        bitmap = loadScene(project.scenes[sceneIndex].image)
                        val scene = project.scenes[sceneIndex]
                        // Optional: use locally cached TFLite models when available.
                        // Rendering still works without them.
                        val ai = runCatching { AiSceneAnalyzer.analyze(context, bitmap!!) }.getOrNull()
                        aiFocusX = ai?.x ?: 0.5f
                        aiFocusY = ai?.y ?: 0.5f
                        aiScale = ai?.scale ?: 1f
                        scene.aiFocusX = aiFocusX
                        scene.aiFocusY = aiFocusY
                        scene.aiSubjectScale = aiScale
                        renderer.setBitmap(bitmap!!)
                    }

                    val scene = project.scenes[sceneIndex]
                    val local = ((tMs - sceneStart).coerceAtLeast(0L).toFloat() /
                            scene.durationMs.coerceAtLeast(1L)).coerceIn(0f, 1f)

                    val zoom = when (scene.cameraMotion) {
                        CameraMotion.ZOOM_OUT -> 1.12f - 0.12f * local
                        CameraMotion.STATIC -> 1.08f
                        else -> 1.0f + 0.12f * local
                    } * aiScale
                    val pan = when (scene.cameraMotion) {
                        CameraMotion.PAN_LEFT -> -0.10f + 0.20f * local
                        CameraMotion.PAN_RIGHT, CameraMotion.FOLLOW -> 0.10f - 0.20f * local
                        else -> 0f
                    }

                    // Subtle character-like bobbing. This is safe 2D motion;
                    // real limb deformation requires a dedicated animation model.
                    val bob = when (scene.characterMotion) {
                        CharacterMotion.RUN -> sin(local * Math.PI * 8).toFloat() * 0.015f
                        CharacterMotion.WALK -> sin(local * Math.PI * 4).toFloat() * 0.008f
                        CharacterMotion.WAVE -> sin(local * Math.PI * 6).toFloat() * 0.006f
                        else -> 0f
                    }

                    renderer.draw(pan, zoom + bob, frame * 1_000_000_000L / FPS, aiFocusX, aiFocusY)
                    drain(false)
                }

                codec.signalEndOfInputStream()
                drain(true)

                renderer.close()
                inputSurface.release()
                codec.stop()
                codec.release()
                if (muxerStarted) muxer.stop()
                muxer.release()
                bitmap?.recycle()

                Result.success(out)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
