package com.photomovie.ai

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val project = MovieProject()
    private lateinit var status: TextView
    private lateinit var addButton: Button
    private lateinit var renderButton: Button

    private val picker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        project.scenes.clear()
        uris.forEach { project.scenes += Scene(it) }
        project.redistributeDuration()
        status.text = "Суратлар: ${project.scenes.size}. Давомийлик: 1 дақиқа."
        renderButton.isEnabled = project.scenes.isNotEmpty()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "PhotoToMovie AI"
            textSize = 28f
        }
        root.addView(title)

        val info = TextView(this).apply {
            text = "Суратларни танланг → AI ҳаракат режасини беринг → 1 дақиқалик MP4 яратинг."
            textSize = 16f
        }
        root.addView(info)

        val script = EditText(this).apply {
            setText(project.script)
            hint = "Сценарий"
            minLines = 3
        }
        root.addView(script)

        addButton = Button(this).apply {
            text = "📸 Суратларни танлаш"
            setOnClickListener { picker.launch("image/*") }
        }
        root.addView(addButton)

        val plan = Button(this).apply {
            text = "✨ AI ҳаракат режаси"
            setOnClickListener {
                project.script = script.text.toString()
                val actions = ScenePlanner.create(project.script)
                project.scenes.forEachIndexed { i, scene ->
                    val a = actions[i % actions.size]
                    scene.characterMotion = a.first
                    scene.cameraMotion = a.second
                }
                status.text = "Ҳаракат режаси тайёр: ${actions.first().first} + ${actions.first().second}"
            }
        }
        root.addView(plan)

        val model = Button(this).apply {
            text = "🧠 AI моделларни 1 марта юклаш"
            setOnClickListener {
                status.text = "Моделлар юкланмоқда…"
                lifecycleScope.launch {
                    val r = ModelManager.ensureModels(this@MainActivity)
                    status.text = if (r.isSuccess)
                        "AI моделлар сақланди. Кейин интернетсиз ишлайди."
                    else
                        "Модел юклаш хатоси: ${r.exceptionOrNull()?.message}"
                }
            }
        }
        root.addView(model)

        renderButton = Button(this).apply {
            text = "🎬 1 дақиқалик видео яратиш"
            isEnabled = false
            setOnClickListener {
                project.script = script.text.toString()
                project.redistributeDuration()
                isEnabled = false
                status.text = "Видео тайёрланмоқда… RAM тежамкор frame-by-frame режим."
                lifecycleScope.launch {
                    val r = OfflineRenderer.render(this@MainActivity, project)
                    status.text = if (r.isSuccess)
                        "Тайёр: ${r.getOrNull()?.absolutePath}"
                    else
                        "Рендер хатоси: ${r.exceptionOrNull()?.message}"
                    isEnabled = true
                }
            }
        }
        root.addView(renderButton)

        status = TextView(this).apply {
            text = "Ҳозирча сурат танланмаган."
            textSize = 15f
        }
        root.addView(status)

        setContentView(root)
    }
}
