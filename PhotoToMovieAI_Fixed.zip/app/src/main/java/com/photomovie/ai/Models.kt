package com.photomovie.ai

import android.net.Uri

enum class CharacterMotion { NONE, WALK, RUN, WAVE, TALK, TURN, LOOK }
enum class CameraMotion { STATIC, ZOOM_IN, ZOOM_OUT, PAN_LEFT, PAN_RIGHT, FOLLOW }
enum class RenderMode { OFFLINE, ONLINE }

data class Scene(
    val image: Uri,
    var durationMs: Long = 5000L,
    var characterMotion: CharacterMotion = CharacterMotion.NONE,
    var cameraMotion: CameraMotion = CameraMotion.ZOOM_IN
)

class MovieProject {
    val scenes = mutableListOf<Scene>()
    var script: String = "Болалар футбол ўйнайди. Улар югуради, тўп тепади ва қувонишади."
    var renderMode: RenderMode = RenderMode.OFFLINE
    var totalDurationMs: Long = 60_000L

    fun redistributeDuration() {
        if (scenes.isEmpty()) return
        val each = totalDurationMs / scenes.size
        scenes.forEachIndexed { i, s ->
            s.durationMs = if (i == scenes.lastIndex)
                totalDurationMs - each * (scenes.size - 1) else each
        }
    }
}
