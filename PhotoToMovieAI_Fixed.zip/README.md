# PhotoToMovie AI — fixed Android project

Бу версияда асосий муаммолар тузатилди:

- ҳақиқий `MediaCodec` H.264 + `MediaMuxer` pipeline;
- OpenGL ES encoder surface;
- frame-by-frame рендер, катта видеони RAM’га тўлиқ юкламайди;
- 1 дақиқа default, максимум 10 дақиқа;
- zoom / pan / follow camera;
- Android gallery’dan кўп сурат танлаш;
- сценарийдан ҳаракат режаси;
- TFLite MoveNet pose модели учун реал inference engine;
- TFLite segmentation engine;
- AI моделлар биринчи марта интернетдан юкланиб, телефон хотирасида сақланади;
- моделлар сақлангандан кейин inference интернетсиз ишлайди.

## Муҳим

`pose_landmark.tflite` ва `segmentation.tflite` binary файлларини атайлаб сохта қилиб қўшилмади.

Илова биринчи марта интернет бор пайтда ModelManager орқали моделларни юклайди:
- pose → MoveNet SinglePose Lightning
- segmentation → MediaPipe Selfie Segmenter

Моделларни APK ичига redistribution қилишдан олдин уларнинг жорий лицензияси ва attribution талабларини текширинг.

## Нима ҳали 100% 3D/генератив AI эмас?

Статик суратда қаҳрамоннинг ҳар бир қўл-оёғини ҳақиқий янги позага деформация қилиш учун pose keypoint’ларини segmentation mask билан бирлаштириб, mesh/warping ёки image-to-video генератив модел қўшиш керак. Бу версияда видео pipeline реал ишлайди ва camera motion бор; character motion эса хавфсиз 2D bobbing/planning даражасида.

## Телефонда build

AndroidIDE ёки бошқа Android IDE’да проектни очинг ва Gradle sync қилинг. Биринчи build интернет талаб қилиши мумкин, чунки Gradle/TFLite dependency’лари юкланади.

APK build бўлгач, телефонга ўрнатинг. AI моделларни бир марта юкланг. Кейин моделлар локал сақланади.
