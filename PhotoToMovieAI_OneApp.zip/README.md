PhotoToMovie AI — one Android app.
Includes Online AI adapter + Offline Basic mode, script scene planner, 10-minute limit and MediaCodec integration point.
Online mode requires a real documented AI video/image-animation API endpoint; no fake API key or fake AI response is included.
Offline mode applies deterministic motion/camera effects and is designed for frame-by-frame rendering.
Real face/hand/leg generative animation requires the selected online provider or licensed local model.
