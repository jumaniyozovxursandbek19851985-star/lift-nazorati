package com.photomovie.ai
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
object AiConfig { const val BASE_URL="https://YOUR-AI-SERVER.example/api/animate" }
data class OnlineAiResult(val videoUrl:String?=null,val error:String?=null)
class OnlineAiClient(private val context:Context) {
 suspend fun animate(image:Uri,script:String,motion:CharacterMotion)=withContext(Dispatchers.IO) {
  try {
   val c=URL(AiConfig.BASE_URL).openConnection() as HttpURLConnection
   c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=15000; c.readTimeout=120000
   c.setRequestProperty("Content-Type","application/json")
   c.outputStream.use{it.write("""{"script":"${script.replace(""","\\"")}","motion":"$motion"}""".toByteArray())}
   val code=c.responseCode
   if(code !in 200..299) return@withContext OnlineAiResult(error="HTTP $code")
   val body=c.inputStream.bufferedReader().use{it.readText()}
   val m="\"videoUrl\":\""; val a=body.indexOf(m)
   if(a<0) OnlineAiResult(error="videoUrl not found")
   else { val s=a+m.length; OnlineAiResult(videoUrl=body.substring(s,body.indexOf("\"",s))) }
  } catch(e:Exception) { OnlineAiResult(error=e.message ?: "Network error") }
 }
}