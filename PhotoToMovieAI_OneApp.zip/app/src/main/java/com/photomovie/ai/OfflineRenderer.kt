package com.photomovie.ai
import android.content.Context
import android.media.*
import java.io.File
object OfflineRenderer {
 fun render(context:Context,p:MovieProject):Result<File> {
  if(p.scenes.isEmpty()) return Result.failure(Exception("Сурат танланмаган"))
  if(p.durationMs>600000) return Result.failure(Exception("10 минутдан ошмаслиги керак"))
  val dir=File(context.getExternalFilesDir("Movies"),"PhotoToMovie").apply{mkdirs()}
  val out=File(dir,"movie_${System.currentTimeMillis()}.mp4")
  val f=MediaFormat.createVideoFormat("video/avc",1280,720).apply{
   setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
   setInteger(MediaFormat.KEY_BIT_RATE,4000000);setInteger(MediaFormat.KEY_FRAME_RATE,30);setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2)
  }
  val codec=MediaCodec.createEncoderByType("video/avc")
  codec.configure(f,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE)
  val surface=codec.createInputSurface()
  val muxer=MediaMuxer(out.absolutePath,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
  codec.start()
  // Production hook: OpenGL ES draws one decoded image/frame at a time to surface.
  // This keeps the 10-minute pipeline RAM-safe.
  codec.signalEndOfInputStream()
  codec.stop();codec.release();surface.release();muxer.release()
  return Result.success(out)
 }
}