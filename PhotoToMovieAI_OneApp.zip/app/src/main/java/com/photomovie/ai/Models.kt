package com.photomovie.ai
import android.net.Uri
enum class CharacterMotion { NONE,WALK,RUN,WAVE,TALK,TURN,LOOK }
enum class CameraMotion { STATIC,ZOOM_IN,ZOOM_OUT,PAN_LEFT,PAN_RIGHT,FOLLOW }
enum class RenderMode { ONLINE_AI,OFFLINE_BASIC }
data class Scene(val image:Uri,var durationMs:Long=4000,var characterMotion:CharacterMotion=CharacterMotion.NONE,var cameraMotion:CameraMotion=CameraMotion.ZOOM_IN)
data class MovieProject(val scenes:MutableList<Scene> = mutableListOf(),var script:String="",var renderMode:RenderMode=RenderMode.ONLINE_AI) {
 val durationMs get()=scenes.sumOf{it.durationMs}
}