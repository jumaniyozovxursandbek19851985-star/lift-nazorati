package com.photomovie.ai
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{App()}}}
 @Composable fun App(){
  val p=remember{MovieProject()};var page by remember{mutableStateOf(0)}
  if(page==0) Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
   Text("PhotoToMovie AI",style=MaterialTheme.typography.headlineLarge)
   Text("Online AI + Offline Basic")
   Spacer(Modifier.height(20.dp));Button({page=1},Modifier.fillMaxWidth()){Text("📸 Суратлардан мультфильм/клип")}
  } else Editor(p){page=0}
 }
 @Composable fun Editor(p:MovieProject,back:()->Unit){
  var busy by remember{mutableStateOf(false)};var status by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
  val pick=rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()){u->u.forEach{p.scenes+=Scene(it)}}
  Column(Modifier.fillMaxSize().padding(16.dp)){
   Text("Лойиҳа",style=MaterialTheme.typography.headlineMedium)
   Row{Button({pick.launch("image/*")}){Text("📸 Қўшиш")};Spacer(Modifier.width(8.dp));OutlinedButton(back){Text("Орқа")}}
   OutlinedTextField(p.script,{p.script=it},Modifier.fillMaxWidth(),label={Text("Сценарий")})
   Row{Button({val a=ScenePlanner.create(p.script);p.scenes.forEachIndexed{i,s->{val x=a[i%a.size];s.characterMotion=x.first;s.cameraMotion=x.second}}}){Text("✨ Ҳаракат")};Spacer(Modifier.width(8.dp));TextButton({p.renderMode=if(p.renderMode==RenderMode.ONLINE_AI)RenderMode.OFFLINE_BASIC else RenderMode.ONLINE_AI}){Text(p.renderMode.name)}}
   Text("Саҳналар: ${p.scenes.size} • %.1f сек.".format(p.durationMs/1000.0))
   Button(enabled=!busy&&p.scenes.isNotEmpty()&&p.durationMs<=600000,onClick={busy=true;scope.launch{
    status=if(p.renderMode==RenderMode.ONLINE_AI)"Online AI endpoint керак: AiConfig.BASE_URL" else "Offline рендер бошланди"
    if(p.renderMode==RenderMode.OFFLINE_BASIC){val r=OfflineRenderer.render(this@MainActivity,p);status=if(r.isSuccess)"Файл: ${r.getOrNull()?.absolutePath}" else "Хато: ${r.exceptionOrNull()?.message}"}
    busy=false
   }},Modifier.fillMaxWidth()){Text(if(busy)"⏳..." else "🎬 Видео яратиш")}
   Text(status)
  }
 }
}