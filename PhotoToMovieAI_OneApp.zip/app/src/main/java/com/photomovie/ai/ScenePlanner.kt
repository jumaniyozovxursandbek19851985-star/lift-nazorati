package com.photomovie.ai
object ScenePlanner {
 fun create(script:String):List<Pair<CharacterMotion,CameraMotion>> {
  val s=script.lowercase(); val r=mutableListOf<Pair<CharacterMotion,CameraMotion>>()
  if(listOf("юрад","юриш","боради").any{s.contains(it)}) r+=CharacterMotion.WALK to CameraMotion.FOLLOW
  if(s.contains("югур")) r+=CharacterMotion.RUN to CameraMotion.FOLLOW
  if(listOf("қўл","силк").any{s.contains(it)}) r+=CharacterMotion.WAVE to CameraMotion.ZOOM_IN
  if(listOf("гапир","сўз").any{s.contains(it)}) r+=CharacterMotion.TALK to CameraMotion.ZOOM_IN
  if(listOf("қара","кўрад").any{s.contains(it)}) r+=CharacterMotion.LOOK to CameraMotion.PAN_RIGHT
  if(r.isEmpty()) r+=CharacterMotion.NONE to CameraMotion.ZOOM_IN
  return r
 }
}